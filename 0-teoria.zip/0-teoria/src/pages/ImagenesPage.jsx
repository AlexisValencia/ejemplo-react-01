import { BtnVolver } from "../components/ui/buttons/BtnVolver";
import imagenlocal from "../assets/img1.jpg";

export const ImagenesPage = () => {
    return(
        <main className="max-w-3xl mx-auto p-6 space-y-10">
            <BtnVolver/>
            <h1 className="text-3xl font-bold text-center" >Imagenes con React</h1>
            <section className="space-y-2"> 
                <h2 className="text-xl font-semibold">Imagen local importada</h2>
                <img loading="lazy" src={imagenlocal} alt="Es una imagen local" />
            </section>
            <section className="space-y-2"> 
                <h2 className="text-xl font-semibold">Imagen como fondo</h2>
                <div className="h-64 bg-cover bg-center rounded-2xl items-center justify-center flex flex-col " style={{backgroundImage: `url(${imagenlocal})`}}>
                    <span className="bg-black/60 px-4 py-2 rounded-2xl text-white font-bold">Fondo con texto encima</span>
                </div>
            </section>
        </main>

    );
}