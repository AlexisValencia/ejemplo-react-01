export const Login = () => {
    return (
        <div className="container mx-auto px-4 bg-black text-white h-screen">
            <h1 className="text-3xl font-bold text-center my-8">Bienvenido al Login</h1>
        </div>
    )
}