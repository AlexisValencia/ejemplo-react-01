import { useEffect, useState } from "react";
import { BtnVolver } from "../components/ui/buttons/BtnVolver";

export const UseEffectPage = () => {
    const [segundos, setSegundos] = useState(0);
    useEffect(() => {
        const intervalo = setInterval(() => {
            setSegundos(prevSegundos => prevSegundos + 1);
        }, 1000);
        return () => clearInterval(intervalo);
    }, []);

    return (
        <div className="h-screen flex flex-col items-center justify-center text-black bg-amber-600">
            <BtnVolver/>
            <h1 className="text-2xl font-bold text-center mt-8">Tiempo en segundos: {segundos}</h1>
        </div>
    );
}