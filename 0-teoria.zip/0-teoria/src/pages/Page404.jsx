export const Page404 = () => {
    return (
        <div className="container mx-auto px-4 bg-black text-white h-screen">
            <h1 className="text-3xl font-bold text-center my-8">Ruta no encontrada</h1>
        </div>
    )
}