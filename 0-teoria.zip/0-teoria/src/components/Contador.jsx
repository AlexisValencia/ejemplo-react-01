import { useState } from "react";
import { Modal } from "./Modal";

export const Contador = () => {
    const [count, setCount] = useState(0);
    const [showModal, setShowModal] = useState(false);
    const incrementar = () =>{
        setCount(count+1)
    }
    const decrementar = () => {
        if(count <= 0) return;
        setCount(count - 1);
    }

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-green-200 via-blue-100 to-purple-200">
            <div className="bg-white rounded-2xl shadow-2xl p-10 flex flex-col items-center gap-6">
                <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-500 via-blue-500 to-purple-500 mb-2 animate-pulse">
                    Contador Bonito
                </h1>
                <span className="text-6xl font-bold text-blue-700 drop-shadow-lg transition-all duration-300 select-none">
                    {count}
                </span>
                <div className="flex gap-4 mt-4">
                    <button
                        className="px-5 py-2 rounded-full bg-gradient-to-r from-green-400 to-blue-500 text-white font-semibold shadow-lg hover:cursor-pointer hover:scale-110 hover:from-green-500 hover:to-blue-600 transition-all duration-200"
                        onClick={incrementar}
                    >
                        +1
                    </button>
                    <button
                        className="px-5 py-2 rounded-full bg-gradient-to-r from-pink-400 to-purple-500 text-white font-semibold shadow-lg hover:cursor-pointer  hover:scale-110 hover:from-pink-500 hover:to-purple-600 transition-all duration-200"
                        onClick={decrementar}
                    >
                        -1
                    </button>
                    <button
                        className="px-5 py-2 rounded-full bg-gray-200 text-gray-700 font-semibold shadow hover:cursor-pointer  hover:bg-gray-300 transition-all duration-200"
                        onClick={() => setCount(0)}
                    >
                        Reset
                    </button>
                </div>
                <button
                    className="mt-6 px-6 py-3 rounded-lg bg-gradient-to-r from-blue-500 to-green-500 text-white font-bold shadow-lg hover:cursor-pointer  hover:from-blue-600 hover:to-green-600 transition-all duration-200"
                    onClick={() => setShowModal(true)}
                >
                    Mostrar Modal
                </button>
            </div>
            {showModal && <Modal/>}
        </div>
    );
};