export const Modal = () => {
    return(
        <div>
            <h1>Hola Mundo, soy un modal, Esto no me gusta nada</h1>
        </div>
    )
}