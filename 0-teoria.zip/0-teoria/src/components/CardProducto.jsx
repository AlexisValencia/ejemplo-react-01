export const CardProducto = ({ item }) => {
    return (
        <article
            className="bg-white rounded-xl shadow-lg p-6 flex flex-col items-center gap-2 w-full max-w-xs mx-auto border border-gray-100 hover:shadow-2xl transition-shadow duration-300 relative"
            role="region"
            aria-label={`Producto: ${item.nombre}`}
        >
            {item.destacado && (
                <span
                    className="absolute top-3 right-3 bg-gradient-to-r from-yellow-400 to-orange-500 text-white text-xs font-bold px-3 py-1 rounded-full shadow animate-bounce"
                    aria-label="Producto destacado"
                >
                    🔥 Destacado
                </span>
            )}
            <div className="w-20 h-20 bg-gradient-to-br from-blue-200 to-purple-200 rounded-full flex items-center justify-center mb-2">
                <span className="text-4xl font-bold text-blue-600" aria-hidden="true">
                    {item.nombre[0]}
                </span>
            </div>
            <h3 className="text-xl font-semibold text-gray-800 text-center">{item.nombre}</h3>
            <p className="text-lg text-green-600 font-bold">${item.precio}</p>
            <button
                className="mt-3 px-4 py-2 bg-gradient-to-r from-green-400 to-blue-500 text-white rounded-full font-semibold shadow hover:scale-105 transition-transform duration-200 focus:outline-none focus:ring-2 focus:ring-blue-400"
                aria-label={`Comprar ${item.nombre}`}
            >
                Comprar
            </button>
        </article>
    );
};