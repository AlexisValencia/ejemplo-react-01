
export const Inform = () => {
    return (
        <div className="w-full px-4 py-8">
            <section className="min-h-screen bg-gradient-to-br from-slate-100 via-blue-50 to-slate-200 flex items-center justify-center">
                <div className="container mx-auto px-4 py-12 max-w-3xl bg-white/90 rounded-2xl shadow-2xl border border-slate-200">
                    <h1 className="text-4xl md:text-5xl font-extrabold text-center text-transparent bg-clip-text bg-gradient-to-r from-blue-800 via-slate-700 to-blue-500 mb-6">
                        Disoft Servicios Informáticos S.L
                    </h1>
                    <h2 className="text-center text-lg md:text-xl font-semibold text-slate-700 mb-8">
                        <span className="font-bold text-blue-800">DISOFT</span> — Excelencia en soluciones digitales desde 1985 en Las Palmas de Gran Canaria
                    </h2>
                    <p className="text-slate-800 text-lg leading-relaxed mb-6 text-center">
                        En <span className="font-bold text-blue-800">DISOFT</span> somos especialistas en <span className="text-blue-700 font-semibold">desarrollo de software</span>, <span className="text-blue-700 font-semibold">desarrollo web</span>, <span className="text-blue-700 font-semibold">ecommerce</span> y sistemas avanzados de <span className="text-blue-700 font-semibold">contabilidad, renta y fiscalidad</span>.
                    </p>
                    <p className="text-slate-800 text-lg leading-relaxed mb-6 text-center">
                        Impulsamos la transformación digital de empresas y comercios, siendo pioneros en la digitalización de <span className="font-bold text-blue-900">Zonas Comerciales Abiertas</span> y ayudando a nuestros clientes a crecer en el mundo digital.
                    </p>
                    <div className="flex flex-col md:flex-row justify-center gap-4 mt-8">
                        <div className="bg-gradient-to-r from-blue-700 to-blue-500 text-white rounded-lg px-6 py-4 shadow text-center font-semibold">
                            Desarrollo Web & Software
                        </div>
                        <div className="bg-gradient-to-r from-slate-700 to-blue-700 text-white rounded-lg px-6 py-4 shadow text-center font-semibold">
                            Ecommerce & Contabilidad
                        </div>
                        <div className="bg-gradient-to-r from-blue-900 to-slate-700 text-white rounded-lg px-6 py-4 shadow text-center font-semibold">
                            Fiscalidad & Zonas Comerciales
                        </div>
                    </div>
                    <p className="text-center text-slate-500 mt-10 text-sm">
                        <span className="font-semibold">Ubicación:</span> Las Palmas de Gran Canaria &middot; <span className="font-semibold">Desde 1985</span>
                    </p>
                </div>
            </section>
        </div>
    );
}