export const HolaMundo = () => {
  return (
    <>
      <div>
        <h1>
          HOLA MI AMOL
        </h1>
      </div>
    </>
  )
}

