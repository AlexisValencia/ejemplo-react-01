import { Icon } from "@iconify/react/dist/iconify.js";
import { Link } from "react-router-dom";

export const CardList = () => {
    const temasTeoria = [
        { title:"UseEffects", to:"/useeffectpage" }, 
        { title:"imagenes",  to:"/ImagenesPage" },
    ];

    return (
        <div className="w-full px-4 py-8 flex flex-col items-center justify-center gap-4">
            {temasTeoria.map((item, index) => (
                <Link to={item.to} key={index} className="w-full bg-amber-950 p-5 rounded-xl border border-amber-600 flex items-center justify-between hover:bg-amber-800 hover:border-amber-50 transition-colors duration-300 cursor-pointer">
                    <h3 className="text-lg font-medium">{item.title}</h3>
                    <Icon icon="fluent-emoji-flat:right-arrow" width="32" height="32" />
                </Link>
            ) )}
        </div>
    );
}