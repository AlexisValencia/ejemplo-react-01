import { Icon } from "@iconify/react";
import { useNavigate } from "react-router-dom";

export const BtnVolver = () => {
    const navigate = useNavigate();
    return (
        <button
            className="fixed top-4 left-4 flex items-center gap-2 px-5 py-2 bg-white text-black rounded-lg shadow-md hover:bg-gray-200 hover:border-blue-700 transition-colors duration-300 z-50 hover:cursor-pointer "
            onClick={() => navigate(-1)}
            aria-label="Volver a la página anterior"
        >
            <Icon icon="pepicons-print:arrow-left" width="20" height="20" />
            Volver
        </button>
    );
};