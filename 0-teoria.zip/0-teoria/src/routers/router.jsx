import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Home } from '../pages/Home';
import { Login } from '../pages/Login';
import { Page404 } from '../pages/Page404';
import { UseEffectPage } from "../pages/UseEffectPage";
import { ImagenesPage } from "../pages/ImagenesPage";



export const MyRoutes = () => {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home/>} />
                <Route path='/login' element={<Login/>}/>
                <Route path="/useeffectpage" element={<UseEffectPage />} />
                <Route path="/imagenespage" element={<ImagenesPage />} />
                <Route path='*' element={<Page404/>}/>
            </Routes>
        </Router>
    );
};
export default MyRoutes;