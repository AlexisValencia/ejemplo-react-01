import React from 'react';
import MyRoutes from './routers/router';
import './index.css';

function App() {


  return (
    <>
      <MyRoutes />
    </>
  );
}

export default App;
